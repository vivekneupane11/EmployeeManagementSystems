const express = require("express");
const router = express.Router();

const upload = require('../documentupload');

const singleUpload = upload.single('document');

router.post('/document-upload', function(req, res) {

  singleUpload(req, res, function(err) {

    if (err) {
      return res.status(422).send({errors: [{title: 'File Upload Error', detail: err.message}] });
    }

    
    return res.json({'documentUrl': req.file.location});
  });
});

module.exports = router;